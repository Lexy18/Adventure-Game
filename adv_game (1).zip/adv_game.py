import time
import random

def print_msg_paused(string):
    print(string)
    time.sleep(1)
    
def sanity_check_input(msg, choices):
    while True:
        user_input = input(msg).lower()
        if user_input in choices:
            return user_input
        else:
            print_msg_paused(f"Sorry, the option {user_input} is invalid. Try again!")

def play():
    initial_options = ["wicked fairie", "pirate", "gorgon"]
    actual_option = random.choice(initial_options)
    
    initialize_scene(actual_option)
    
    chosen = []
    field(chosen, actual_option)

def initialize_scene(option):
    s1 = ("You find yourself standing in an open field, " + 
          "filled with grass and yellow wildflowers.")
    s2 = (f"Tittle-tattle has it that a {option} is somewhere out there" +
        "it has been troubling the whole village")
    s3 = "In front of you is a house."
    s4 = "To your right is a dark cave."
    s5 = ("In your hand you hold your trusty (but not very " + 
          "effective) dagger.\n")
    ss = [s1, s2, s3, s4, s5]
    
    for s in ss:
        print_msg_paused(s)

def field(chosen, option):
    s1 = "Enter 1 to knock on the door of the house."
    s2 = "Enter 2 to peer into the cave."
    s3 = "What would you like to do?"
    ss = [s1, s2, s3]
    
    for s in ss:
        print_msg_paused(s)
    
    msg = "Please enter 1 or 2.\n"
    choices = ["1", "2"]
    user_choice = int(sanity_check_input(msg, choices))
    if user_choice == 1:
        house(chosen, option)
    elif user_choice == 2:
        cave(chosen, option)
        
def cave(chosen, option):
    if "sword" in chosen:
        s1 = "\nYou peer cautiously into the cave."
        s2 = ("You've been here before, and gotten all" + 
             " the good stuff. It's just an empty cave now.")
        s3 = "You walk back to the field.\n"
        ss = [s1, s2, s3]
        
        for s in ss:
            print_msg_paused(s)
    else:
        s1 = "\nYou peer cautiously into the cave."
        s2 = "It turns out to be only a very small cave."
        s3 = "Your eye catches a glint of metal behind a rock."
        s4 = "You have found the magical Sword of Ogoroth!"
        s5 = ("You discard your silly old dagger and take" + 
             "the sword with you.")
        s6 = "You walk back out to the field.\n"
        ss = [s1, s2, s3, s4, s5, s6]
        
        for s in ss:
            print_msg_paused(s)
        
        chosen.append("sword")
    
    field(chosen, option)
    
def house(chosen, option):
    s1 = "\nYou approach the door of the house."
    s2 = ("You are about to knock when the door " + 
          "opens and out steps a " + option + ".")
    s3 = "Eep! This is the " + option + "'s house!"
    s4 = "The " + option + " attacks you!\n"
    ss = [s1, s2, s3, s4]
    
    for s in ss:
        print_msg_paused(s)
        
    if "sword" not in chosen:
        s = ("You feel a bit under-prepared for this, " + 
             "what with only having a tiny dagger.\n")
        print_msg_paused(s)
    
    msg = "Would you like to (1) fight or (2) run away?\n"
    choices = ["1", "2"]
    user_choice = int(sanity_check_input(msg, choices))
    if user_choice == 1:
        fight(chosen, option)
    elif user_choice == 2:
        s = ("\nYou run back into the field. " + 
             "Luckily, you don't seem to have been " + 
             "followed.\n")
        print_msg_paused(s)
        field(chosen, option)

def fight(chosen, option):
    if "sword" in chosen:
        s1 = ("\nAs the " + option + " moves to attack, " + 
              "you unsheath your new sword.")
        s2 = ("The Sword of Ogoroth shines brightly in " + 
              "your hand as you brace yourself for the attack.")
        s3 = ("But the " + option + " takes one look at " + 
              "your shiny new toy and runs away!")
        s4 = ("You have rid the town of the " + option + 
              ". You are victorious!\n")
        ss = [s1, s2, s3, s4]
    
        for s in ss:
            print_msg_paused(s)
    else:
        s1 = "\nYou do your best..."
        s2 = "but your dagger is no match for the " + option + "."
        s3 = "You have been defeated!\n"
        ss = [s1, s2, s3]
    
        for s in ss:
            print_msg_paused(s)
    
    play_again()

def play_again():
    msg = "Would you like to play again? (y/n)\n"
    choices = ["y", "n"]
    user_choice = sanity_check_input(msg, choices)
    if user_choice == "y":
        print_msg_paused("Excellent! Restarting the game ...\n")
        play()
    elif user_choice == "n":
        print_msg_paused("Thanks for playing! See you next time.")
        return()

if __name__ == "__main__":
    play()
